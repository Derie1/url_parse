from urllib.parse import urlparse
