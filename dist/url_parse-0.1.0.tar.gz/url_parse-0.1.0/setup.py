# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['url_parse']
install_requires = \
['pytest>=7.1.3,<8.0.0']

setup_kwargs = {
    'name': 'url-parse',
    'version': '0.1.0',
    'description': 'Exercise for make abstractions for url manipulating',
    'long_description': None,
    'author': 'Mikhail Davydov',
    'author_email': 'mdavydov83@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
